var quizData = [
    {
        question : "Which one of these languages are used in Web Design?", //insert question
        a : "Java",
        b : "C",
        c : "Python",         //insert answers in a,b,c and d
        d : "JavaScript",
        correct : "d",           //insert correct answer
    },
    {
        question : "What is CSS short of?",
        a : "Central Style Sheets",
        b : "Cascading Style Sheets",
        c : "Cascading Simple Sheets",
        d : "Cars SUVs Sailbots",
        correct : "b",
    },
    {
        question : "What is HTML short of?",
        a : "HyperText Markup Language",
        b : "HyperText markdown Language",
        c : "Hyperloop Machine Language",
        d : "Helicopters Terminals Moroboas Lamborghinis",
        correct : "a",
    },
    {
        question: "What year was JavaScript created?",
        a : "1996",
        b : "1995",
        c : "1994",
        d : "None of the above",
        correct : "b",
    }
];

var quiz = document.getElementById('quiz');


var answerEls = document.querySelectorAll('input');
var question = document.getElementById('question');
var a_text = document.getElementById('a_text');
var b_text = document.getElementById('b_text');
var c_text = document.getElementById('c_text');
var d_text = document.getElementById('d_text');
var submitBtn = document.getElementById('submit');

var currentQuestion = 0;
var score = 0;

loadQuiz();

function loadQuiz() {
    deselectAnswers();
    currentQuestionData = quizData[currentQuestion];
    question.innerText = currentQuestionData.question;
    a_text.innerHTML = currentQuestionData.a;
    b_text.innerHTML = currentQuestionData.b;
    c_text.innerHTML = currentQuestionData.c;
    d_text.innerHTML = currentQuestionData.d;
}

function deselectAnswers () {
    answerEls.forEach(answer => answer.checked = false)
}

function getSelectedAnswer() {
    answer = undefined;

    answerEls.forEach(answerEl =>{
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })
    return answer;
}

submitBtn.addEventListener('click', () => {
    answer = getSelectedAnswer();

    if(answer != undefined) {
        if(answer == quizData[currentQuestion].correct) {
            score++
        }

        currentQuestion++;
        
        if(currentQuestion < quizData.length) {
            loadQuiz();
        }
        else {
            quiz.innerHTML = `
                <h2>You answered ${score} out of ${quizData.length} questions right</h2>
                <button onclick = "reload()"> Try Again </button>
            `
        }   
    }
    else {
        alert('You didnt pick any answer')
    }
})
function reload() {
    location.reload()
}